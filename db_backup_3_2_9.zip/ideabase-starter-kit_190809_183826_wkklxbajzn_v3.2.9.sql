-- MySQL dump 10.13  Distrib 5.6.38, for osx10.9 (x86_64)
--
-- Host: localhost    Database: starterkit
-- ------------------------------------------------------
-- Server version	5.6.38

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `craft_assetindexdata`
--

DROP TABLE IF EXISTS `craft_assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` varchar(36) NOT NULL DEFAULT '',
  `volumeId` int(11) NOT NULL,
  `uri` text,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `recordId` int(11) DEFAULT NULL,
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_assetindexdata_sessionId_volumeId_idx` (`sessionId`,`volumeId`),
  KEY `craft_assetindexdata_volumeId_idx` (`volumeId`),
  CONSTRAINT `craft_assetindexdata_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `craft_volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_assets`
--

DROP TABLE IF EXISTS `craft_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_assets_folderId_idx` (`folderId`),
  KEY `craft_assets_volumeId_idx` (`volumeId`),
  KEY `craft_assets_volumeId_keptFile_idx` (`volumeId`,`keptFile`),
  CONSTRAINT `craft_assets_folderId_fk` FOREIGN KEY (`folderId`) REFERENCES `craft_volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_assets_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_assets_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `craft_volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_assettransformindex`
--

DROP TABLE IF EXISTS `craft_assettransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_assettransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_assettransformindex_volumeId_assetId_location_idx` (`volumeId`,`assetId`,`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_assettransforms`
--

DROP TABLE IF EXISTS `craft_assettransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_assettransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `dimensionChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_assettransforms_name_unq_idx` (`name`),
  UNIQUE KEY `craft_assettransforms_handle_unq_idx` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_categories`
--

DROP TABLE IF EXISTS `craft_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_categories_groupId_idx` (`groupId`),
  KEY `craft_categories_parentId_fk` (`parentId`),
  CONSTRAINT `craft_categories_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_categories_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_categories_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `craft_categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_categorygroups`
--

DROP TABLE IF EXISTS `craft_categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_categorygroups_structureId_idx` (`structureId`),
  KEY `craft_categorygroups_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `craft_categorygroups_dateDeleted_idx` (`dateDeleted`),
  KEY `craft_categorygroups_name_idx` (`name`),
  KEY `craft_categorygroups_handle_idx` (`handle`),
  CONSTRAINT `craft_categorygroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_categorygroups_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_categorygroups_sites`
--

DROP TABLE IF EXISTS `craft_categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_categorygroups_sites_groupId_siteId_unq_idx` (`groupId`,`siteId`),
  KEY `craft_categorygroups_sites_siteId_idx` (`siteId`),
  CONSTRAINT `craft_categorygroups_sites_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_categorygroups_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_content`
--

DROP TABLE IF EXISTS `craft_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_email` varchar(255) DEFAULT NULL,
  `field_redactor` text,
  `field_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_content_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `craft_content_siteId_idx` (`siteId`),
  KEY `craft_content_title_idx` (`title`),
  CONSTRAINT `craft_content_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_content_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_craftidtokens`
--

DROP TABLE IF EXISTS `craft_craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_craftidtokens_userId_fk` (`userId`),
  CONSTRAINT `craft_craftidtokens_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_deprecationerrors`
--

DROP TABLE IF EXISTS `craft_deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `traces` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_deprecationerrors_key_fingerprint_unq_idx` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_drafts`
--

DROP TABLE IF EXISTS `craft_drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sourceId` int(11) DEFAULT NULL,
  `creatorId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  KEY `craft_drafts_creatorId_fk` (`creatorId`),
  KEY `craft_drafts_sourceId_fk` (`sourceId`),
  CONSTRAINT `craft_drafts_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_drafts_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_elementindexsettings`
--

DROP TABLE IF EXISTS `craft_elementindexsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_elementindexsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_elementindexsettings_type_unq_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_elements`
--

DROP TABLE IF EXISTS `craft_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `draftId` int(11) DEFAULT NULL,
  `revisionId` int(11) DEFAULT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_elements_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `craft_elements_type_idx` (`type`),
  KEY `craft_elements_enabled_idx` (`enabled`),
  KEY `craft_elements_archived_dateCreated_idx` (`archived`,`dateCreated`),
  KEY `craft_elements_dateDeleted_idx` (`dateDeleted`),
  KEY `craft_elements_draftId_fk` (`draftId`),
  KEY `craft_elements_revisionId_fk` (`revisionId`),
  CONSTRAINT `craft_elements_draftId_fk` FOREIGN KEY (`draftId`) REFERENCES `craft_drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_elements_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_elements_revisionId_fk` FOREIGN KEY (`revisionId`) REFERENCES `craft_revisions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_elements_sites`
--

DROP TABLE IF EXISTS `craft_elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_elements_sites_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `craft_elements_sites_siteId_idx` (`siteId`),
  KEY `craft_elements_sites_slug_siteId_idx` (`slug`,`siteId`),
  KEY `craft_elements_sites_enabled_idx` (`enabled`),
  KEY `craft_elements_sites_uri_siteId_idx` (`uri`,`siteId`),
  CONSTRAINT `craft_elements_sites_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_elements_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_entries`
--

DROP TABLE IF EXISTS `craft_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_entries_postDate_idx` (`postDate`),
  KEY `craft_entries_expiryDate_idx` (`expiryDate`),
  KEY `craft_entries_authorId_idx` (`authorId`),
  KEY `craft_entries_sectionId_idx` (`sectionId`),
  KEY `craft_entries_typeId_idx` (`typeId`),
  KEY `craft_entries_parentId_fk` (`parentId`),
  CONSTRAINT `craft_entries_authorId_fk` FOREIGN KEY (`authorId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entries_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entries_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `craft_entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_entries_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entries_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `craft_entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_entrydrafterrors`
--

DROP TABLE IF EXISTS `craft_entrydrafterrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_entrydrafterrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `draftId` int(11) DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `craft_entrydrafterrors_draftId_fk` (`draftId`),
  CONSTRAINT `craft_entrydrafterrors_draftId_fk` FOREIGN KEY (`draftId`) REFERENCES `craft_entrydrafts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_entrydrafts`
--

DROP TABLE IF EXISTS `craft_entrydrafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_entrydrafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `creatorId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `notes` text,
  `data` mediumtext NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_entrydrafts_sectionId_idx` (`sectionId`),
  KEY `craft_entrydrafts_entryId_siteId_idx` (`entryId`,`siteId`),
  KEY `craft_entrydrafts_siteId_idx` (`siteId`),
  KEY `craft_entrydrafts_creatorId_idx` (`creatorId`),
  CONSTRAINT `craft_entrydrafts_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entrydrafts_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `craft_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entrydrafts_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entrydrafts_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_entrytypes`
--

DROP TABLE IF EXISTS `craft_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleLabel` varchar(255) DEFAULT 'Title',
  `titleFormat` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_entrytypes_sectionId_idx` (`sectionId`),
  KEY `craft_entrytypes_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `craft_entrytypes_dateDeleted_idx` (`dateDeleted`),
  KEY `craft_entrytypes_name_sectionId_idx` (`name`,`sectionId`),
  KEY `craft_entrytypes_handle_sectionId_idx` (`handle`,`sectionId`),
  CONSTRAINT `craft_entrytypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_entrytypes_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_entryversionerrors`
--

DROP TABLE IF EXISTS `craft_entryversionerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_entryversionerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `versionId` int(11) DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `craft_entryversionerrors_versionId_fk` (`versionId`),
  CONSTRAINT `craft_entryversionerrors_versionId_fk` FOREIGN KEY (`versionId`) REFERENCES `craft_entryversions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_entryversions`
--

DROP TABLE IF EXISTS `craft_entryversions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_entryversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `siteId` int(11) NOT NULL,
  `num` smallint(6) unsigned NOT NULL,
  `notes` text,
  `data` mediumtext NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_entryversions_sectionId_idx` (`sectionId`),
  KEY `craft_entryversions_entryId_siteId_idx` (`entryId`,`siteId`),
  KEY `craft_entryversions_siteId_idx` (`siteId`),
  KEY `craft_entryversions_creatorId_idx` (`creatorId`),
  CONSTRAINT `craft_entryversions_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_entryversions_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `craft_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entryversions_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entryversions_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_fieldgroups`
--

DROP TABLE IF EXISTS `craft_fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_fieldgroups_name_unq_idx` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_fieldlayoutfields`
--

DROP TABLE IF EXISTS `craft_fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_fieldlayoutfields_layoutId_fieldId_unq_idx` (`layoutId`,`fieldId`),
  KEY `craft_fieldlayoutfields_sortOrder_idx` (`sortOrder`),
  KEY `craft_fieldlayoutfields_tabId_idx` (`tabId`),
  KEY `craft_fieldlayoutfields_fieldId_idx` (`fieldId`),
  CONSTRAINT `craft_fieldlayoutfields_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fieldlayoutfields_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fieldlayoutfields_tabId_fk` FOREIGN KEY (`tabId`) REFERENCES `craft_fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_fieldlayouts`
--

DROP TABLE IF EXISTS `craft_fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_fieldlayouts_type_idx` (`type`),
  KEY `craft_fieldlayouts_dateDeleted_idx` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_fieldlayouttabs`
--

DROP TABLE IF EXISTS `craft_fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_fieldlayouttabs_sortOrder_idx` (`sortOrder`),
  KEY `craft_fieldlayouttabs_layoutId_idx` (`layoutId`),
  CONSTRAINT `craft_fieldlayouttabs_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_fields`
--

DROP TABLE IF EXISTS `craft_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_fields_handle_context_unq_idx` (`handle`,`context`),
  KEY `craft_fields_groupId_idx` (`groupId`),
  KEY `craft_fields_context_idx` (`context`),
  CONSTRAINT `craft_fields_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_globalsets`
--

DROP TABLE IF EXISTS `craft_globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_globalsets_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `craft_globalsets_name_idx` (`name`),
  KEY `craft_globalsets_handle_idx` (`handle`),
  CONSTRAINT `craft_globalsets_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_globalsets_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_info`
--

DROP TABLE IF EXISTS `craft_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `config` mediumtext,
  `configMap` mediumtext,
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_matrixblocks`
--

DROP TABLE IF EXISTS `craft_matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_matrixblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_matrixblocks_ownerId_idx` (`ownerId`),
  KEY `craft_matrixblocks_fieldId_idx` (`fieldId`),
  KEY `craft_matrixblocks_typeId_idx` (`typeId`),
  KEY `craft_matrixblocks_sortOrder_idx` (`sortOrder`),
  CONSTRAINT `craft_matrixblocks_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocks_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocks_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocks_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `craft_matrixblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_matrixblocktypes`
--

DROP TABLE IF EXISTS `craft_matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_matrixblocktypes_name_fieldId_unq_idx` (`name`,`fieldId`),
  UNIQUE KEY `craft_matrixblocktypes_handle_fieldId_unq_idx` (`handle`,`fieldId`),
  KEY `craft_matrixblocktypes_fieldId_idx` (`fieldId`),
  KEY `craft_matrixblocktypes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `craft_matrixblocktypes_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocktypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_matrixcontent_links`
--

DROP TABLE IF EXISTS `craft_matrixcontent_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_matrixcontent_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_block_linkName` text,
  `field_block_linkUrl` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_matrixcontent_links_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `craft_matrixcontent_links_siteId_fk` (`siteId`),
  CONSTRAINT `craft_matrixcontent_links_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixcontent_links_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_migrations`
--

DROP TABLE IF EXISTS `craft_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pluginId` int(11) DEFAULT NULL,
  `type` enum('app','plugin','content') NOT NULL DEFAULT 'app',
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_migrations_pluginId_idx` (`pluginId`),
  KEY `craft_migrations_type_pluginId_idx` (`type`,`pluginId`),
  CONSTRAINT `craft_migrations_pluginId_fk` FOREIGN KEY (`pluginId`) REFERENCES `craft_plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_plugins`
--

DROP TABLE IF EXISTS `craft_plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `licenseKeyStatus` enum('valid','invalid','mismatched','astray','unknown') NOT NULL DEFAULT 'unknown',
  `licensedEdition` varchar(255) DEFAULT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_plugins_handle_unq_idx` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_queue`
--

DROP TABLE IF EXISTS `craft_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `craft_queue_fail_timeUpdated_timePushed_idx` (`fail`,`timeUpdated`,`timePushed`),
  KEY `craft_queue_fail_timeUpdated_delay_idx` (`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_relations`
--

DROP TABLE IF EXISTS `craft_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_relations_fieldId_sourceId_sourceSiteId_targetId_unq_idx` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `craft_relations_sourceId_idx` (`sourceId`),
  KEY `craft_relations_targetId_idx` (`targetId`),
  KEY `craft_relations_sourceSiteId_idx` (`sourceSiteId`),
  CONSTRAINT `craft_relations_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_relations_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_relations_sourceSiteId_fk` FOREIGN KEY (`sourceSiteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_relations_targetId_fk` FOREIGN KEY (`targetId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_resourcepaths`
--

DROP TABLE IF EXISTS `craft_resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_revisions`
--

DROP TABLE IF EXISTS `craft_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_revisions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sourceId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `num` int(11) NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_revisions_sourceId_num_unq_idx` (`sourceId`,`num`),
  KEY `craft_revisions_creatorId_fk` (`creatorId`),
  CONSTRAINT `craft_revisions_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_revisions_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_searchindex`
--

DROP TABLE IF EXISTS `craft_searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `craft_searchindex_keywords_idx` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_sections`
--

DROP TABLE IF EXISTS `craft_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `previewTargets` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_sections_structureId_idx` (`structureId`),
  KEY `craft_sections_dateDeleted_idx` (`dateDeleted`),
  KEY `craft_sections_name_idx` (`name`),
  KEY `craft_sections_handle_idx` (`handle`),
  CONSTRAINT `craft_sections_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_sections_sites`
--

DROP TABLE IF EXISTS `craft_sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_sections_sites_sectionId_siteId_unq_idx` (`sectionId`,`siteId`),
  KEY `craft_sections_sites_siteId_idx` (`siteId`),
  CONSTRAINT `craft_sections_sites_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_sections_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_sequences`
--

DROP TABLE IF EXISTS `craft_sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_sequences` (
  `name` varchar(255) NOT NULL,
  `next` int(11) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_sessions`
--

DROP TABLE IF EXISTS `craft_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_sessions_uid_idx` (`uid`),
  KEY `craft_sessions_token_idx` (`token`),
  KEY `craft_sessions_dateUpdated_idx` (`dateUpdated`),
  KEY `craft_sessions_userId_idx` (`userId`),
  CONSTRAINT `craft_sessions_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_shunnedmessages`
--

DROP TABLE IF EXISTS `craft_shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_shunnedmessages_userId_message_unq_idx` (`userId`,`message`),
  CONSTRAINT `craft_shunnedmessages_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_sitegroups`
--

DROP TABLE IF EXISTS `craft_sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_sitegroups_dateDeleted_idx` (`dateDeleted`),
  KEY `craft_sitegroups_name_idx` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_sites`
--

DROP TABLE IF EXISTS `craft_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_sites_sortOrder_idx` (`sortOrder`),
  KEY `craft_sites_groupId_fk` (`groupId`),
  KEY `craft_sites_dateDeleted_idx` (`dateDeleted`),
  KEY `craft_sites_handle_idx` (`handle`),
  CONSTRAINT `craft_sites_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_structureelements`
--

DROP TABLE IF EXISTS `craft_structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_structureelements_structureId_elementId_unq_idx` (`structureId`,`elementId`),
  KEY `craft_structureelements_root_idx` (`root`),
  KEY `craft_structureelements_lft_idx` (`lft`),
  KEY `craft_structureelements_rgt_idx` (`rgt`),
  KEY `craft_structureelements_level_idx` (`level`),
  KEY `craft_structureelements_elementId_idx` (`elementId`),
  CONSTRAINT `craft_structureelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_structureelements_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_structures`
--

DROP TABLE IF EXISTS `craft_structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_structures_dateDeleted_idx` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_systemmessages`
--

DROP TABLE IF EXISTS `craft_systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_systemmessages_key_language_unq_idx` (`key`,`language`),
  KEY `craft_systemmessages_language_idx` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_taggroups`
--

DROP TABLE IF EXISTS `craft_taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_taggroups_fieldLayoutId_fk` (`fieldLayoutId`),
  KEY `craft_taggroups_dateDeleted_idx` (`dateDeleted`),
  KEY `craft_taggroups_name_idx` (`name`),
  KEY `craft_taggroups_handle_idx` (`handle`),
  CONSTRAINT `craft_taggroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_tags`
--

DROP TABLE IF EXISTS `craft_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_tags_groupId_idx` (`groupId`),
  CONSTRAINT `craft_tags_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_tags_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_templatecacheelements`
--

DROP TABLE IF EXISTS `craft_templatecacheelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_templatecacheelements` (
  `cacheId` int(11) NOT NULL,
  `elementId` int(11) NOT NULL,
  KEY `craft_templatecacheelements_cacheId_idx` (`cacheId`),
  KEY `craft_templatecacheelements_elementId_idx` (`elementId`),
  CONSTRAINT `craft_templatecacheelements_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `craft_templatecaches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_templatecacheelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_templatecachequeries`
--

DROP TABLE IF EXISTS `craft_templatecachequeries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_templatecachequeries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `query` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_templatecachequeries_cacheId_idx` (`cacheId`),
  KEY `craft_templatecachequeries_type_idx` (`type`),
  CONSTRAINT `craft_templatecachequeries_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `craft_templatecaches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_templatecaches`
--

DROP TABLE IF EXISTS `craft_templatecaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_templatecaches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteId` int(11) NOT NULL,
  `cacheKey` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `body` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_templatecaches_cacheKey_siteId_expiryDate_path_idx` (`cacheKey`,`siteId`,`expiryDate`,`path`),
  KEY `craft_templatecaches_cacheKey_siteId_expiryDate_idx` (`cacheKey`,`siteId`,`expiryDate`),
  KEY `craft_templatecaches_siteId_idx` (`siteId`),
  CONSTRAINT `craft_templatecaches_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_tokens`
--

DROP TABLE IF EXISTS `craft_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_tokens_token_unq_idx` (`token`),
  KEY `craft_tokens_expiryDate_idx` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_usergroups`
--

DROP TABLE IF EXISTS `craft_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_usergroups_handle_unq_idx` (`handle`),
  UNIQUE KEY `craft_usergroups_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_usergroups_users`
--

DROP TABLE IF EXISTS `craft_usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_usergroups_users_groupId_userId_unq_idx` (`groupId`,`userId`),
  KEY `craft_usergroups_users_userId_idx` (`userId`),
  CONSTRAINT `craft_usergroups_users_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_usergroups_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_userpermissions`
--

DROP TABLE IF EXISTS `craft_userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_userpermissions_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_userpermissions_usergroups`
--

DROP TABLE IF EXISTS `craft_userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_userpermissions_usergroups_permissionId_groupId_unq_idx` (`permissionId`,`groupId`),
  KEY `craft_userpermissions_usergroups_groupId_idx` (`groupId`),
  CONSTRAINT `craft_userpermissions_usergroups_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_userpermissions_usergroups_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `craft_userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_userpermissions_users`
--

DROP TABLE IF EXISTS `craft_userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_userpermissions_users_permissionId_userId_unq_idx` (`permissionId`,`userId`),
  KEY `craft_userpermissions_users_userId_idx` (`userId`),
  CONSTRAINT `craft_userpermissions_users_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `craft_userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_userpermissions_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_userpreferences`
--

DROP TABLE IF EXISTS `craft_userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` text,
  PRIMARY KEY (`userId`),
  CONSTRAINT `craft_userpreferences_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_users`
--

DROP TABLE IF EXISTS `craft_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_users_uid_idx` (`uid`),
  KEY `craft_users_verificationCode_idx` (`verificationCode`),
  KEY `craft_users_email_idx` (`email`),
  KEY `craft_users_username_idx` (`username`),
  KEY `craft_users_photoId_fk` (`photoId`),
  CONSTRAINT `craft_users_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_users_photoId_fk` FOREIGN KEY (`photoId`) REFERENCES `craft_assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_volumefolders`
--

DROP TABLE IF EXISTS `craft_volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_volumefolders_name_parentId_volumeId_unq_idx` (`name`,`parentId`,`volumeId`),
  KEY `craft_volumefolders_parentId_idx` (`parentId`),
  KEY `craft_volumefolders_volumeId_idx` (`volumeId`),
  CONSTRAINT `craft_volumefolders_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `craft_volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_volumefolders_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `craft_volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_volumes`
--

DROP TABLE IF EXISTS `craft_volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `url` varchar(255) DEFAULT NULL,
  `settings` text,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_volumes_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `craft_volumes_dateDeleted_idx` (`dateDeleted`),
  KEY `craft_volumes_name_idx` (`name`),
  KEY `craft_volumes_handle_idx` (`handle`),
  CONSTRAINT `craft_volumes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craft_widgets`
--

DROP TABLE IF EXISTS `craft_widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(3) DEFAULT NULL,
  `settings` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_widgets_userId_idx` (`userId`),
  CONSTRAINT `craft_widgets_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'starterkit'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-09 14:38:28
-- MySQL dump 10.13  Distrib 5.6.38, for osx10.9 (x86_64)
--
-- Host: localhost    Database: starterkit
-- ------------------------------------------------------
-- Server version	5.6.38

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `craft_assets`
--

LOCK TABLES `craft_assets` WRITE;
/*!40000 ALTER TABLE `craft_assets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_assettransforms`
--

LOCK TABLES `craft_assettransforms` WRITE;
/*!40000 ALTER TABLE `craft_assettransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_assettransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_categories`
--

LOCK TABLES `craft_categories` WRITE;
/*!40000 ALTER TABLE `craft_categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_categorygroups`
--

LOCK TABLES `craft_categorygroups` WRITE;
/*!40000 ALTER TABLE `craft_categorygroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_categorygroups_sites`
--

LOCK TABLES `craft_categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `craft_categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_content`
--

LOCK TABLES `craft_content` WRITE;
/*!40000 ALTER TABLE `craft_content` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `craft_content` VALUES (1,1,1,NULL,'2018-09-10 18:44:20','2018-09-10 18:44:20','89f7b123-d2ff-4832-87e2-c2e30b25e124',NULL,NULL,NULL);
/*!40000 ALTER TABLE `craft_content` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_craftidtokens`
--

LOCK TABLES `craft_craftidtokens` WRITE;
/*!40000 ALTER TABLE `craft_craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_deprecationerrors`
--

LOCK TABLES `craft_deprecationerrors` WRITE;
/*!40000 ALTER TABLE `craft_deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_drafts`
--

LOCK TABLES `craft_drafts` WRITE;
/*!40000 ALTER TABLE `craft_drafts` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_elementindexsettings`
--

LOCK TABLES `craft_elementindexsettings` WRITE;
/*!40000 ALTER TABLE `craft_elementindexsettings` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_elementindexsettings` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_elements`
--

LOCK TABLES `craft_elements` WRITE;
/*!40000 ALTER TABLE `craft_elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `craft_elements` VALUES (1,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2018-09-10 18:44:20','2018-09-10 18:44:20',NULL,'251a5124-4b99-4de3-8961-0c53b6fda93a');
/*!40000 ALTER TABLE `craft_elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_elements_sites`
--

LOCK TABLES `craft_elements_sites` WRITE;
/*!40000 ALTER TABLE `craft_elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `craft_elements_sites` VALUES (1,1,1,NULL,NULL,1,'2018-09-10 18:44:20','2018-09-10 18:44:20','f897426b-be77-4f33-829e-e53eef42f778');
/*!40000 ALTER TABLE `craft_elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_entries`
--

LOCK TABLES `craft_entries` WRITE;
/*!40000 ALTER TABLE `craft_entries` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_entrydrafterrors`
--

LOCK TABLES `craft_entrydrafterrors` WRITE;
/*!40000 ALTER TABLE `craft_entrydrafterrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_entrydrafterrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_entrydrafts`
--

LOCK TABLES `craft_entrydrafts` WRITE;
/*!40000 ALTER TABLE `craft_entrydrafts` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_entrydrafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_entrytypes`
--

LOCK TABLES `craft_entrytypes` WRITE;
/*!40000 ALTER TABLE `craft_entrytypes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_entryversionerrors`
--

LOCK TABLES `craft_entryversionerrors` WRITE;
/*!40000 ALTER TABLE `craft_entryversionerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_entryversionerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_entryversions`
--

LOCK TABLES `craft_entryversions` WRITE;
/*!40000 ALTER TABLE `craft_entryversions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_entryversions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_fieldgroups`
--

LOCK TABLES `craft_fieldgroups` WRITE;
/*!40000 ALTER TABLE `craft_fieldgroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `craft_fieldgroups` VALUES (1,'Common','2018-09-10 18:44:19','2018-09-10 18:44:19','25c472cd-7268-4fff-aecc-5c378337631d');
/*!40000 ALTER TABLE `craft_fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_fieldlayoutfields`
--

LOCK TABLES `craft_fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `craft_fieldlayoutfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `craft_fieldlayoutfields` VALUES (1,1,1,3,1,1,'2019-07-26 15:42:48','2019-07-26 15:42:48','d49f4eff-3b4e-43d5-9b5e-fa1dfee1d109'),(2,1,1,4,1,2,'2019-07-26 15:42:48','2019-07-26 15:42:48','ff47636c-d769-4052-8109-70afec081d4d');
/*!40000 ALTER TABLE `craft_fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_fieldlayouts`
--

LOCK TABLES `craft_fieldlayouts` WRITE;
/*!40000 ALTER TABLE `craft_fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `craft_fieldlayouts` VALUES (1,'craft\\elements\\MatrixBlock','2019-07-26 15:42:47','2019-07-26 15:42:47',NULL,'ba8cb6e6-2e84-405d-ac24-17a59237a6ba');
/*!40000 ALTER TABLE `craft_fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_fieldlayouttabs`
--

LOCK TABLES `craft_fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `craft_fieldlayouttabs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `craft_fieldlayouttabs` VALUES (1,1,'Content',1,'2019-07-26 15:42:47','2019-07-26 15:42:47','be2a94e8-c573-4966-804a-ee46b493e705');
/*!40000 ALTER TABLE `craft_fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_fields`
--

LOCK TABLES `craft_fields` WRITE;
/*!40000 ALTER TABLE `craft_fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `craft_fields` VALUES (1,1,'Email','email','global','',1,'none',NULL,'craft\\fields\\Email','{\"placeholder\":\"\"}','2019-07-26 15:40:24','2019-07-26 15:40:24','5fcd9147-334a-4080-b90e-944f3089ee07'),(2,1,'Links','links','global','',1,'site',NULL,'craft\\fields\\Matrix','{\"minBlocks\":\"\",\"maxBlocks\":\"\",\"contentTable\":\"{{%matrixcontent_links}}\",\"propagationMethod\":\"all\"}','2019-07-26 15:42:47','2019-07-26 15:42:47','438cc2b3-de13-44f0-b434-51cd9856b2b8'),(3,NULL,'Link Name','linkName','matrixBlockType:d88b56ff-6132-45dd-b4f5-887b2738c0c1','',1,'none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2019-07-26 15:42:47','2019-07-26 15:42:47','42dda43e-c0d3-4936-b3ba-93ad7717c72e'),(4,NULL,'Link URL','linkUrl','matrixBlockType:d88b56ff-6132-45dd-b4f5-887b2738c0c1','',1,'none',NULL,'craft\\fields\\Url','{\"placeholder\":\"\",\"maxLength\":\"255\"}','2019-07-26 15:42:47','2019-07-26 15:42:47','6badbf59-6404-4c1f-861e-2fe29d14ce4d'),(5,1,'Redactor','redactor','global','',1,'none',NULL,'craft\\redactor\\Field','{\"redactorConfig\":\"\",\"purifierConfig\":\"\",\"cleanupHtml\":true,\"removeInlineStyles\":\"1\",\"removeEmptyTags\":\"1\",\"removeNbsp\":\"1\",\"purifyHtml\":\"1\",\"columnType\":\"text\",\"availableVolumes\":\"*\",\"availableTransforms\":\"*\"}','2019-07-26 15:43:02','2019-07-26 15:43:02','97b75968-ae66-450b-b5c3-6c3c7d329838'),(6,1,'Date','date','global','',1,'none',NULL,'craft\\fields\\Date','{\"showDate\":true,\"showTime\":false,\"minuteIncrement\":\"30\"}','2019-07-26 15:46:22','2019-07-26 15:46:22','e7ef617b-da76-488a-8cf0-38578acf5e8c');
/*!40000 ALTER TABLE `craft_fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_globalsets`
--

LOCK TABLES `craft_globalsets` WRITE;
/*!40000 ALTER TABLE `craft_globalsets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_info`
--

LOCK TABLES `craft_info` WRITE;
/*!40000 ALTER TABLE `craft_info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `craft_info` VALUES (1,'3.2.9','3.2.16',0,'{\"dateModified\":1564155982,\"siteGroups\":{\"91ccd827-4c84-49fb-84c8-e2d3b2a7c7d1\":{\"name\":\"IdeaBase Starter Kit\"}},\"sites\":{\"37224b75-40a6-4c0e-9b6b-3136edacdf9f\":{\"name\":\"IdeaBase Starter Kit\",\"handle\":\"default\",\"language\":\"en-US\",\"hasUrls\":\"1\",\"baseUrl\":\"@web/\",\"sortOrder\":\"1\",\"primary\":\"1\",\"siteGroup\":\"91ccd827-4c84-49fb-84c8-e2d3b2a7c7d1\"}},\"sections\":[],\"fieldGroups\":{\"25c472cd-7268-4fff-aecc-5c378337631d\":{\"name\":\"Common\"}},\"fields\":{\"5fcd9147-334a-4080-b90e-944f3089ee07\":{\"name\":\"Email\",\"handle\":\"email\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Email\",\"settings\":{\"placeholder\":\"\"},\"contentColumnType\":\"string\",\"fieldGroup\":\"25c472cd-7268-4fff-aecc-5c378337631d\"},\"438cc2b3-de13-44f0-b434-51cd9856b2b8\":{\"name\":\"Links\",\"handle\":\"links\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"site\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Matrix\",\"settings\":{\"minBlocks\":\"\",\"maxBlocks\":\"\",\"contentTable\":\"{{%matrixcontent_links}}\",\"propagationMethod\":\"all\"},\"contentColumnType\":\"string\",\"fieldGroup\":\"25c472cd-7268-4fff-aecc-5c378337631d\"},\"97b75968-ae66-450b-b5c3-6c3c7d329838\":{\"name\":\"Redactor\",\"handle\":\"redactor\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\redactor\\\\Field\",\"settings\":{\"redactorConfig\":\"\",\"purifierConfig\":\"\",\"cleanupHtml\":true,\"removeInlineStyles\":\"1\",\"removeEmptyTags\":\"1\",\"removeNbsp\":\"1\",\"purifyHtml\":\"1\",\"columnType\":\"text\",\"availableVolumes\":\"*\",\"availableTransforms\":\"*\"},\"contentColumnType\":\"text\",\"fieldGroup\":\"25c472cd-7268-4fff-aecc-5c378337631d\"},\"e7ef617b-da76-488a-8cf0-38578acf5e8c\":{\"name\":\"Date\",\"handle\":\"date\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Date\",\"settings\":{\"showDate\":true,\"showTime\":false,\"minuteIncrement\":\"30\"},\"contentColumnType\":\"datetime\",\"fieldGroup\":\"25c472cd-7268-4fff-aecc-5c378337631d\"}},\"matrixBlockTypes\":{\"d88b56ff-6132-45dd-b4f5-887b2738c0c1\":{\"field\":\"438cc2b3-de13-44f0-b434-51cd9856b2b8\",\"name\":\"block\",\"handle\":\"block\",\"sortOrder\":1,\"fields\":{\"42dda43e-c0d3-4936-b3ba-93ad7717c72e\":{\"name\":\"Link Name\",\"handle\":\"linkName\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\PlainText\",\"settings\":{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"},\"contentColumnType\":\"text\",\"fieldGroup\":null},\"6badbf59-6404-4c1f-861e-2fe29d14ce4d\":{\"name\":\"Link URL\",\"handle\":\"linkUrl\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Url\",\"settings\":{\"placeholder\":\"\",\"maxLength\":\"255\"},\"contentColumnType\":\"string(255)\",\"fieldGroup\":null}},\"fieldLayouts\":{\"ba8cb6e6-2e84-405d-ac24-17a59237a6ba\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"42dda43e-c0d3-4936-b3ba-93ad7717c72e\":{\"required\":true,\"sortOrder\":1},\"6badbf59-6404-4c1f-861e-2fe29d14ce4d\":{\"required\":true,\"sortOrder\":2}}}]}}}},\"volumes\":[],\"categoryGroups\":[],\"tagGroups\":[],\"users\":{\"requireEmailVerification\":true,\"allowPublicRegistration\":false,\"defaultGroup\":null,\"photoVolumeUid\":null,\"photoSubpath\":\"\"},\"globalSets\":[],\"plugins\":{\"redactor\":{\"settings\":null,\"licenseKey\":null,\"enabled\":\"1\",\"schemaVersion\":\"2.3.0\"}},\"email\":{\"fromEmail\":\"info@ideabasekent.com\",\"fromName\":\"IdeaBase Starter Kit\",\"transportType\":\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"},\"system\":{\"edition\":\"solo\",\"live\":true,\"name\":\"IdeaBase Starter Kit\",\"timeZone\":\"America/New_York\",\"schemaVersion\":\"3.2.16\"},\"imageTransforms\":[],\"routes\":[]}',NULL,'yX2AuDJC96x6','2018-09-10 18:44:19','2019-07-23 18:33:09','d3ab3ff3-7dad-49c0-9e6d-f03f2c73fb07');
/*!40000 ALTER TABLE `craft_info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_matrixblocks`
--

LOCK TABLES `craft_matrixblocks` WRITE;
/*!40000 ALTER TABLE `craft_matrixblocks` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_matrixblocktypes`
--

LOCK TABLES `craft_matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `craft_matrixblocktypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `craft_matrixblocktypes` VALUES (1,2,1,'block','block',1,'2019-07-26 15:42:48','2019-07-26 15:42:48','d88b56ff-6132-45dd-b4f5-887b2738c0c1');
/*!40000 ALTER TABLE `craft_matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_matrixcontent_links`
--

LOCK TABLES `craft_matrixcontent_links` WRITE;
/*!40000 ALTER TABLE `craft_matrixcontent_links` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_matrixcontent_links` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_migrations`
--

LOCK TABLES `craft_migrations` WRITE;
/*!40000 ALTER TABLE `craft_migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `craft_migrations` VALUES (1,NULL,'app','Install','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','110d4b5f-9e5c-4dd1-8675-affef4fef06c'),(2,NULL,'app','m150403_183908_migrations_table_changes','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','92a31ef0-8b85-4ed9-a04e-ffecb139547d'),(3,NULL,'app','m150403_184247_plugins_table_changes','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','aa3dbdee-07d2-4659-9510-47af9499aec5'),(4,NULL,'app','m150403_184533_field_version','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','9d5211a8-73fb-4079-a013-7a4e5657664a'),(5,NULL,'app','m150403_184729_type_columns','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','61960326-8840-49a5-8277-78988680c9ea'),(6,NULL,'app','m150403_185142_volumes','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','f587bf4b-3433-43b8-9347-62454c483a02'),(7,NULL,'app','m150428_231346_userpreferences','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','111cbec2-f561-4303-9f36-e38c5cf42fbb'),(8,NULL,'app','m150519_150900_fieldversion_conversion','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','4e5edcd1-9e07-4f2e-96fe-ca116b724d36'),(9,NULL,'app','m150617_213829_update_email_settings','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','3fbc4cca-520e-487a-a37a-4ec0cbfb8efb'),(10,NULL,'app','m150721_124739_templatecachequeries','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','5b53e5bb-0e8a-4281-a6bd-cfae1195c1e4'),(11,NULL,'app','m150724_140822_adjust_quality_settings','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','0b2f1075-8593-47e1-9783-7dde3eb88531'),(12,NULL,'app','m150815_133521_last_login_attempt_ip','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','bda5f83d-9def-437c-aad3-58b0539fdaf0'),(13,NULL,'app','m151002_095935_volume_cache_settings','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','5007075a-6338-481c-96d9-375382089512'),(14,NULL,'app','m151005_142750_volume_s3_storage_settings','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','6e53c09c-e635-48a4-9e22-72aef78a403c'),(15,NULL,'app','m151016_133600_delete_asset_thumbnails','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','edb9d4fc-98c8-44da-9b1f-e29308b8583c'),(16,NULL,'app','m151209_000000_move_logo','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','76db86a1-56eb-40b8-987c-6a674aecdc84'),(17,NULL,'app','m151211_000000_rename_fileId_to_assetId','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','10598342-4a90-4a4d-9de3-cb8f4c4779e2'),(18,NULL,'app','m151215_000000_rename_asset_permissions','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','4fdd6a35-9d77-4d38-8e56-9aa7dda5af21'),(19,NULL,'app','m160707_000001_rename_richtext_assetsource_setting','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','fca6b936-0b8c-4f4f-8e6a-d985e384c9fa'),(20,NULL,'app','m160708_185142_volume_hasUrls_setting','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','d1881fd1-09b1-4622-b32c-f5cb86bb4fdf'),(21,NULL,'app','m160714_000000_increase_max_asset_filesize','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','2ba63344-4c85-4e65-b382-ace09fdc2221'),(22,NULL,'app','m160727_194637_column_cleanup','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','b30da556-b503-440d-9797-a501be9eed0a'),(23,NULL,'app','m160804_110002_userphotos_to_assets','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','a161c626-e4a5-434f-9c02-ccbaee11cbce'),(24,NULL,'app','m160807_144858_sites','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','c1a34681-8ccd-472d-a24c-63043bff9a98'),(25,NULL,'app','m160829_000000_pending_user_content_cleanup','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','a3205070-d685-4cb5-8f01-78014f5cbb65'),(26,NULL,'app','m160830_000000_asset_index_uri_increase','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','1581e4ba-2ab4-4462-bf22-65e924746f7b'),(27,NULL,'app','m160912_230520_require_entry_type_id','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','cd31301f-423f-4e38-8732-02c4cf7e7417'),(28,NULL,'app','m160913_134730_require_matrix_block_type_id','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','e4e77c4a-1cc2-4ea4-972b-a3300ad519ae'),(29,NULL,'app','m160920_174553_matrixblocks_owner_site_id_nullable','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','a80ea226-1619-47c3-b57f-dd55c6003f5c'),(30,NULL,'app','m160920_231045_usergroup_handle_title_unique','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','3b2b9864-042d-43f9-8ce6-b6acb9dc9680'),(31,NULL,'app','m160925_113941_route_uri_parts','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','91cf4639-8f3f-4ba9-9e9b-b3f7c48ade29'),(32,NULL,'app','m161006_205918_schemaVersion_not_null','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','c95b6931-04c8-4988-a293-4ee1134e88e4'),(33,NULL,'app','m161007_130653_update_email_settings','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','a2f63077-1b21-45ef-a0ca-f61735e014da'),(34,NULL,'app','m161013_175052_newParentId','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','36973f93-0a70-492b-83bf-d77f6deaf4b4'),(35,NULL,'app','m161021_102916_fix_recent_entries_widgets','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','7680ec04-440e-40e5-98ad-7e219e109167'),(36,NULL,'app','m161021_182140_rename_get_help_widget','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','2c952edc-9af8-47fc-92c8-9d40f6e76069'),(37,NULL,'app','m161025_000000_fix_char_columns','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','51b4bd58-13e0-4d43-b593-aea6f26938b1'),(38,NULL,'app','m161029_124145_email_message_languages','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','720f474f-adbe-4a7e-a8f4-579435466b4c'),(39,NULL,'app','m161108_000000_new_version_format','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','fd07cbe0-3a07-488f-a122-48635d28d6c1'),(40,NULL,'app','m161109_000000_index_shuffle','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','647a6a5f-6593-41de-901a-3d4226a912ba'),(41,NULL,'app','m161122_185500_no_craft_app','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','3fdace5f-a015-4f9f-9a63-3228b80530c9'),(42,NULL,'app','m161125_150752_clear_urlmanager_cache','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','deddaf06-df4c-4bf0-86bc-30ae918674b4'),(43,NULL,'app','m161220_000000_volumes_hasurl_notnull','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','52616c83-3cd8-4b9c-9ab2-792480c4d833'),(44,NULL,'app','m170114_161144_udates_permission','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','948c2a7c-2f40-4486-9055-a3c8f23e9633'),(45,NULL,'app','m170120_000000_schema_cleanup','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','5293d5a0-5d95-4680-b8ad-ae35deab07b9'),(46,NULL,'app','m170126_000000_assets_focal_point','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','ebcad3a4-5871-4307-842b-2986e57ac6e1'),(47,NULL,'app','m170206_142126_system_name','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','e6416247-3ba4-4049-9c02-83115c877d60'),(48,NULL,'app','m170217_044740_category_branch_limits','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','eeedce00-1e02-4632-b0df-a9a69ea422f6'),(49,NULL,'app','m170217_120224_asset_indexing_columns','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','9559c310-4d87-4557-98bc-a3b262d390d0'),(50,NULL,'app','m170223_224012_plain_text_settings','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','e854656a-0041-48ff-96e4-c5dc10bc5921'),(51,NULL,'app','m170227_120814_focal_point_percentage','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','1985f2d1-a4aa-4e9e-96bd-d4e2ae29b29d'),(52,NULL,'app','m170228_171113_system_messages','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','80f84321-199f-45eb-b18b-5c6fb8cafe20'),(53,NULL,'app','m170303_140500_asset_field_source_settings','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','6c98f30b-a8ce-476b-a2f4-92080243b1e3'),(54,NULL,'app','m170306_150500_asset_temporary_uploads','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','65af8aa4-0fd5-4988-b43a-6cf658b41a78'),(55,NULL,'app','m170414_162429_rich_text_config_setting','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','b6d1baa9-6905-4fe7-bc07-a49805c829e3'),(56,NULL,'app','m170523_190652_element_field_layout_ids','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','0cd89c56-62cd-410f-b8e0-9c9f0fddd305'),(57,NULL,'app','m170612_000000_route_index_shuffle','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','a3cec4dc-fa2f-45fb-bd2a-3044ee4d8f54'),(58,NULL,'app','m170621_195237_format_plugin_handles','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','edf7a1f5-7ac7-4da8-aa14-6d74fb317bfc'),(59,NULL,'app','m170630_161028_deprecation_changes','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','14c4e278-c5d9-4e0d-9e14-f9b940e9a350'),(60,NULL,'app','m170703_181539_plugins_table_tweaks','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','087f11da-b2e4-474c-9e1c-656913c4b93e'),(61,NULL,'app','m170704_134916_sites_tables','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','4476d74b-4a1d-4c1a-ab25-099424dc3acc'),(62,NULL,'app','m170706_183216_rename_sequences','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','04263ab6-f208-4b66-8d13-47545ba0b289'),(63,NULL,'app','m170707_094758_delete_compiled_traits','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','f08699c1-fc22-4fcc-b4d6-f6c3a88c96cc'),(64,NULL,'app','m170731_190138_drop_asset_packagist','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','119aae48-83c8-4c7f-b068-3cecf619435b'),(65,NULL,'app','m170810_201318_create_queue_table','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','02c12235-ea40-4e71-bad6-6dc34a7d3bd9'),(66,NULL,'app','m170816_133741_delete_compiled_behaviors','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','fa1fdcfc-29eb-4e66-99f5-c8ecc2616742'),(67,NULL,'app','m170821_180624_deprecation_line_nullable','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','cc334805-9bc3-4047-9ba7-23e7af6857bf'),(68,NULL,'app','m170903_192801_longblob_for_queue_jobs','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','6243003c-a30a-4c0d-9735-509ec06d5bf0'),(69,NULL,'app','m170914_204621_asset_cache_shuffle','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','ebd41818-4d83-402e-a1c9-15de5d87a91a'),(70,NULL,'app','m171011_214115_site_groups','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','51dad7ba-fb6e-4473-b306-d6907c525757'),(71,NULL,'app','m171012_151440_primary_site','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','f6c528c1-02d1-4427-bea2-5ede1f8b367f'),(72,NULL,'app','m171013_142500_transform_interlace','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','0c415473-f6e9-4870-a639-ebb581f2c4f0'),(73,NULL,'app','m171016_092553_drop_position_select','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','ee1f91eb-9df6-4115-a585-d66586312069'),(74,NULL,'app','m171016_221244_less_strict_translation_method','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','8ad70bf7-a09a-49b1-87a4-84dc593dcdb3'),(75,NULL,'app','m171107_000000_assign_group_permissions','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','d3729d97-ca91-49ac-abda-097989c16f05'),(76,NULL,'app','m171117_000001_templatecache_index_tune','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','38ff4cc9-4534-408f-af02-811c3c44cc25'),(77,NULL,'app','m171126_105927_disabled_plugins','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','de6a7632-59e7-410c-9471-75427851423c'),(78,NULL,'app','m171130_214407_craftidtokens_table','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','b72a738f-f43b-454a-9ec7-9ecfb333ca50'),(79,NULL,'app','m171202_004225_update_email_settings','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','98e20635-d2fb-4b32-b959-0d709fe89795'),(80,NULL,'app','m171204_000001_templatecache_index_tune_deux','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','c84d9432-5b27-4867-ad87-0d4d70f89a10'),(81,NULL,'app','m171205_130908_remove_craftidtokens_refreshtoken_column','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','c1c4785a-f9af-4f5e-b820-b11e438449f1'),(82,NULL,'app','m171218_143135_longtext_query_column','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','a927eb2d-c6fa-45f6-8868-fe4940520ff7'),(83,NULL,'app','m171231_055546_environment_variables_to_aliases','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','491065b6-21bf-4a71-a779-3608dde13b05'),(84,NULL,'app','m180113_153740_drop_users_archived_column','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','380c767b-4631-4bbb-98b1-9cb94d224b42'),(85,NULL,'app','m180122_213433_propagate_entries_setting','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','ab7310a0-5566-4e1d-a6a2-71e49227bc83'),(86,NULL,'app','m180124_230459_fix_propagate_entries_values','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','b97f9e16-8600-48c8-9563-7d9d3bb78f39'),(87,NULL,'app','m180128_235202_set_tag_slugs','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','801520e2-b670-4ee3-9558-131eaca89a54'),(88,NULL,'app','m180202_185551_fix_focal_points','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','2e2b1ad2-ff75-44fc-99f0-9b13d54fd533'),(89,NULL,'app','m180217_172123_tiny_ints','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','3a35f3bf-8e31-4eb6-9b81-e2b622059ae0'),(90,NULL,'app','m180321_233505_small_ints','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','6c1e2068-7897-4aac-9ceb-2eecf50243aa'),(91,NULL,'app','m180328_115523_new_license_key_statuses','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','71c73435-aa6e-4354-89b8-49ca9ad6a5ae'),(92,NULL,'app','m180404_182320_edition_changes','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','2c17f142-26df-4f0d-980d-5dbe4d344249'),(93,NULL,'app','m180411_102218_fix_db_routes','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','780fedd6-7e6d-4726-a415-f570c67b58ce'),(94,NULL,'app','m180416_205628_resourcepaths_table','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','4044d0d3-b408-4a91-a434-1f8cdef077b8'),(95,NULL,'app','m180418_205713_widget_cleanup','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','882945fd-a84a-4d21-add4-288ad8bdc2a1'),(96,NULL,'app','m180824_193422_case_sensitivity_fixes','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','b0276c24-1193-44be-818c-f4781aeadf75'),(97,NULL,'app','m180901_151639_fix_matrixcontent_tables','2018-09-10 18:44:21','2018-09-10 18:44:21','2018-09-10 18:44:21','6cb13d08-f079-4ea9-aca9-fd8dced5a67d'),(98,2,'plugin','m180430_204710_remove_old_plugins','2018-09-10 18:46:39','2018-09-10 18:46:39','2018-09-10 18:46:39','bc5619b6-6392-4070-b805-5b30f296b0ab'),(99,2,'plugin','Install','2018-09-10 18:46:39','2018-09-10 18:46:39','2018-09-10 18:46:39','f3b2a144-0df5-4703-ac65-9f496a5baceb'),(100,NULL,'app','m181112_203955_sequences_table','2019-01-07 18:29:21','2019-01-07 18:29:21','2019-01-07 18:29:21','4eed5bd2-ff8c-45ef-bad4-2bc6e5fa70c9'),(101,NULL,'app','m170630_161027_deprecation_line_nullable','2019-02-18 16:07:22','2019-02-18 16:07:22','2019-02-18 16:07:22','dc41f8cd-a10c-4d27-a02e-ec9325dc93c9'),(102,NULL,'app','m180425_203349_searchable_fields','2019-02-18 16:07:22','2019-02-18 16:07:22','2019-02-18 16:07:22','67a014d5-ec3d-4927-b6c0-3ae305cc157a'),(103,NULL,'app','m180516_153000_uids_in_field_settings','2019-02-18 16:07:22','2019-02-18 16:07:22','2019-02-18 16:07:22','e24584b7-b64c-4be8-a4cf-baab5e3df2b7'),(104,NULL,'app','m180517_173000_user_photo_volume_to_uid','2019-02-18 16:07:22','2019-02-18 16:07:22','2019-02-18 16:07:22','702fcab4-cbfa-42a2-b1f0-574696041222'),(105,NULL,'app','m180518_173000_permissions_to_uid','2019-02-18 16:07:22','2019-02-18 16:07:22','2019-02-18 16:07:22','5a0e95cd-8756-42fe-8457-d72901293ebf'),(106,NULL,'app','m180520_173000_matrix_context_to_uids','2019-02-18 16:07:22','2019-02-18 16:07:22','2019-02-18 16:07:22','040d1680-eac8-47f1-9219-d9366b7d070c'),(107,NULL,'app','m180521_173000_initial_yml_and_snapshot','2019-02-18 16:07:22','2019-02-18 16:07:22','2019-02-18 16:07:22','1c029c47-42a4-48b3-ac8e-cfb73613e7af'),(108,NULL,'app','m180731_162030_soft_delete_sites','2019-02-18 16:07:22','2019-02-18 16:07:22','2019-02-18 16:07:22','c06b3622-ccaf-4b93-8fb0-004735e1fff4'),(109,NULL,'app','m180810_214427_soft_delete_field_layouts','2019-02-18 16:07:22','2019-02-18 16:07:22','2019-02-18 16:07:22','c5bb8969-74b4-4742-8979-8f4aa4125720'),(110,NULL,'app','m180810_214439_soft_delete_elements','2019-02-18 16:07:22','2019-02-18 16:07:22','2019-02-18 16:07:22','23d91f63-1fb9-4682-9e49-c9761cd97c41'),(111,NULL,'app','m180904_112109_permission_changes','2019-02-18 16:07:22','2019-02-18 16:07:22','2019-02-18 16:07:22','675ef352-8b39-48e6-b2b5-fbefa6e32a88'),(112,NULL,'app','m180910_142030_soft_delete_sitegroups','2019-02-18 16:07:22','2019-02-18 16:07:22','2019-02-18 16:07:22','77f29eac-0914-41e2-bfe5-c3dd724f7598'),(113,NULL,'app','m181011_160000_soft_delete_asset_support','2019-02-18 16:07:22','2019-02-18 16:07:22','2019-02-18 16:07:22','775ef2cb-1e93-4afe-ba06-4902a853b84c'),(114,NULL,'app','m181016_183648_set_default_user_settings','2019-02-18 16:07:22','2019-02-18 16:07:22','2019-02-18 16:07:22','3af516d9-7aee-47c2-aa41-15f63b74b7b4'),(115,NULL,'app','m181017_225222_system_config_settings','2019-02-18 16:07:22','2019-02-18 16:07:22','2019-02-18 16:07:22','b798af43-6ea8-4c7b-b56b-084e1d0b62fc'),(116,NULL,'app','m181018_222343_drop_userpermissions_from_config','2019-02-18 16:07:22','2019-02-18 16:07:22','2019-02-18 16:07:22','2a1362b6-8f73-4b0a-9ade-9695d5c90529'),(117,NULL,'app','m181029_130000_add_transforms_routes_to_config','2019-02-18 16:07:23','2019-02-18 16:07:23','2019-02-18 16:07:23','98272d5d-92bc-4e8f-bb3f-9902f3ce8bba'),(118,NULL,'app','m181121_001712_cleanup_field_configs','2019-02-18 16:07:23','2019-02-18 16:07:23','2019-02-18 16:07:23','bea595f4-d23e-41e1-a818-6cdcebc45020'),(119,NULL,'app','m181128_193942_fix_project_config','2019-02-18 16:07:23','2019-02-18 16:07:23','2019-02-18 16:07:23','d43bc95c-210f-4296-b001-da9718a66f9a'),(120,NULL,'app','m181130_143040_fix_schema_version','2019-02-18 16:07:23','2019-02-18 16:07:23','2019-02-18 16:07:23','689ba7ca-9b1e-4595-be46-45d44119b917'),(121,NULL,'app','m181211_143040_fix_entry_type_uids','2019-02-18 16:07:23','2019-02-18 16:07:23','2019-02-18 16:07:23','f2fd6745-ab6e-40da-ae7b-bbab4b0e419d'),(122,NULL,'app','m181213_102500_config_map_aliases','2019-02-18 16:07:23','2019-02-18 16:07:23','2019-02-18 16:07:23','e3c1916d-11c7-49eb-bb3a-e6e7f9fb3f77'),(123,NULL,'app','m181217_153000_fix_structure_uids','2019-02-18 16:07:23','2019-02-18 16:07:23','2019-02-18 16:07:23','330cbaf9-d834-4878-ab11-9b12cc8b10eb'),(124,NULL,'app','m190104_152725_store_licensed_plugin_editions','2019-02-18 16:07:23','2019-02-18 16:07:23','2019-02-18 16:07:23','bb18f3c9-38da-4df2-b575-21cbbc661314'),(125,NULL,'app','m190108_110000_cleanup_project_config','2019-02-18 16:07:23','2019-02-18 16:07:23','2019-02-18 16:07:23','1964deb9-2e90-4853-b45d-249ffc1f3879'),(126,NULL,'app','m190108_113000_asset_field_setting_change','2019-02-18 16:07:23','2019-02-18 16:07:23','2019-02-18 16:07:23','c0b13eca-7999-4253-9751-0015265ab338'),(127,NULL,'app','m190109_172845_fix_colspan','2019-02-18 16:07:23','2019-02-18 16:07:23','2019-02-18 16:07:23','7cc390d4-e172-4462-9b24-7f8b65d6ffad'),(128,NULL,'app','m190110_150000_prune_nonexisting_sites','2019-02-18 16:07:23','2019-02-18 16:07:23','2019-02-18 16:07:23','34a94612-cd0d-4799-ac9d-89de6f4d3776'),(129,NULL,'app','m190110_214819_soft_delete_volumes','2019-02-18 16:07:23','2019-02-18 16:07:23','2019-02-18 16:07:23','32d4188c-27c8-4e1c-81b9-24da1c640e75'),(130,NULL,'app','m190112_124737_fix_user_settings','2019-02-18 16:07:23','2019-02-18 16:07:23','2019-02-18 16:07:23','3ba7f3ce-f994-4b8e-a3b9-0777dc1f50f4'),(131,NULL,'app','m190112_131225_fix_field_layouts','2019-02-18 16:07:23','2019-02-18 16:07:23','2019-02-18 16:07:23','ed13b30f-ca84-4778-820e-fdd09d60c80c'),(132,NULL,'app','m190112_201010_more_soft_deletes','2019-02-18 16:07:23','2019-02-18 16:07:23','2019-02-18 16:07:23','ee5078ab-3589-4dad-bc8e-5635339849a1'),(133,NULL,'app','m190114_143000_more_asset_field_setting_changes','2019-02-18 16:07:23','2019-02-18 16:07:23','2019-02-18 16:07:23','9ab72311-a528-4b3b-a0a4-5a1ec3d29108'),(134,NULL,'app','m190121_120000_rich_text_config_setting','2019-02-18 16:07:23','2019-02-18 16:07:23','2019-02-18 16:07:23','db9d28f9-2ded-4582-8606-ca5f60eb0290'),(135,NULL,'app','m190125_191628_fix_email_transport_password','2019-02-18 16:07:23','2019-02-18 16:07:23','2019-02-18 16:07:23','b96dbca1-7e43-4308-91ed-f84eb1c56ba9'),(136,NULL,'app','m190128_181422_cleanup_volume_folders','2019-02-18 16:07:23','2019-02-18 16:07:23','2019-02-18 16:07:23','ba755d44-b889-4a8e-afe6-96bb0cc08f76'),(137,NULL,'app','m190205_140000_fix_asset_soft_delete_index','2019-02-18 16:07:24','2019-02-18 16:07:24','2019-02-18 16:07:24','59e67234-823e-481d-a737-3ab734053078'),(138,NULL,'app','m190208_140000_reset_project_config_mapping','2019-02-18 16:07:24','2019-02-18 16:07:24','2019-02-18 16:07:24','2d9044b7-7db0-4ee5-9f3e-92f2ed807223'),(139,NULL,'app','m190218_143000_element_index_settings_uid','2019-02-18 16:07:24','2019-02-18 16:07:24','2019-02-18 16:07:24','09e87e6a-c952-40cb-8bea-a34510a27581'),(140,2,'plugin','m181101_110000_ids_in_settings_to_uids','2019-02-18 16:07:40','2019-02-18 16:07:40','2019-02-18 16:07:40','7a121ebc-9a90-48ec-ab72-c2b6175ea2cb'),(141,NULL,'app','m190401_223843_drop_old_indexes','2019-04-13 00:39:45','2019-04-13 00:39:45','2019-04-13 00:39:45','160fbbc9-a6b1-4124-9bf0-d61632933517'),(142,NULL,'app','m190416_014525_drop_unique_global_indexes','2019-05-15 18:21:27','2019-05-15 18:21:27','2019-05-15 18:21:27','45b549eb-0e0a-45b6-9e34-bc5571373740'),(143,NULL,'app','m190502_122019_store_default_user_group_uid','2019-05-15 18:21:27','2019-05-15 18:21:27','2019-05-15 18:21:27','84913f56-b2ca-4959-a5cb-5514b650408e'),(144,2,'plugin','m190225_003922_split_cleanup_html_settings','2019-05-15 18:21:40','2019-05-15 18:21:40','2019-05-15 18:21:40','adc4fa17-e65e-4b6e-99c5-2440e0cde217'),(145,NULL,'app','m190312_152740_element_revisions','2019-07-23 18:33:22','2019-07-23 18:33:22','2019-07-23 18:33:22','f3f51363-8cf4-484d-a000-f2cb01b97dd8'),(146,NULL,'app','m190327_235137_propagation_method','2019-07-23 18:33:22','2019-07-23 18:33:22','2019-07-23 18:33:22','8593248f-01d5-4092-98d2-1b5b9f4fb08b'),(147,NULL,'app','m190417_085010_add_image_editor_permissions','2019-07-23 18:33:22','2019-07-23 18:33:22','2019-07-23 18:33:22','5ab255f2-02b0-4fd0-aff6-c7ca42450035'),(148,NULL,'app','m190504_150349_preview_targets','2019-07-23 18:33:22','2019-07-23 18:33:22','2019-07-23 18:33:22','f61c62f4-18d5-44f2-aa3f-9d85d22b804a'),(149,NULL,'app','m190516_184711_job_progress_label','2019-07-23 18:33:22','2019-07-23 18:33:22','2019-07-23 18:33:22','cb1af647-9806-422b-88dc-2d9e33d06bc8'),(150,NULL,'app','m190523_190303_optional_revision_creators','2019-07-23 18:33:22','2019-07-23 18:33:22','2019-07-23 18:33:22','a3625d33-7af3-4974-b39a-c28ef0719365'),(151,NULL,'app','m190529_204501_fix_duplicate_uids','2019-07-23 18:33:22','2019-07-23 18:33:22','2019-07-23 18:33:22','6bebb378-778a-4767-9ebb-f00f426ced0d'),(152,NULL,'app','m190605_223807_unsaved_drafts','2019-07-23 18:33:22','2019-07-23 18:33:22','2019-07-23 18:33:22','c1767707-bad8-4a81-8de5-df8ea6367d36'),(153,NULL,'app','m190607_230042_entry_revision_error_tables','2019-07-23 18:33:22','2019-07-23 18:33:22','2019-07-23 18:33:22','6e890107-4fd7-48c4-a772-544aaf1e1f20'),(154,NULL,'app','m190608_033429_drop_elements_uid_idx','2019-07-23 18:33:22','2019-07-23 18:33:22','2019-07-23 18:33:22','ef063447-6148-4cc7-ba8c-b881699d0355'),(155,NULL,'app','m190624_234204_matrix_propagation_method','2019-07-23 18:33:22','2019-07-23 18:33:22','2019-07-23 18:33:22','3732dd8f-d2b1-45d5-839d-63e1d8a00a13'),(156,NULL,'app','m190711_153020_drop_snapshots','2019-07-23 18:33:22','2019-07-23 18:33:22','2019-07-23 18:33:22','e9fbaf06-4dcf-4a29-99e3-18172728e7be'),(157,NULL,'app','m190712_195914_no_draft_revisions','2019-07-23 18:33:22','2019-07-23 18:33:22','2019-07-23 18:33:22','31671610-2b30-4db6-a2fd-a795159b2cca'),(158,NULL,'app','m190723_140314_fix_preview_targets_column','2019-07-23 18:33:22','2019-07-23 18:33:22','2019-07-23 18:33:22','fd0f46fe-b016-41a0-9eac-2bda79ce5b09');
/*!40000 ALTER TABLE `craft_migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_plugins`
--

LOCK TABLES `craft_plugins` WRITE;
/*!40000 ALTER TABLE `craft_plugins` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `craft_plugins` VALUES (2,'redactor','2.3.3.2','2.3.0','unknown',NULL,'2018-09-10 18:46:39','2018-09-10 18:46:39','2019-08-09 17:31:08','aff7fbd0-e997-4599-8844-a82c6d3cbd1d');
/*!40000 ALTER TABLE `craft_plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_queue`
--

LOCK TABLES `craft_queue` WRITE;
/*!40000 ALTER TABLE `craft_queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_relations`
--

LOCK TABLES `craft_relations` WRITE;
/*!40000 ALTER TABLE `craft_relations` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_resourcepaths`
--

LOCK TABLES `craft_resourcepaths` WRITE;
/*!40000 ALTER TABLE `craft_resourcepaths` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `craft_resourcepaths` VALUES ('103d4a5c','@lib/fileupload'),('10b03506','@lib/jquery.payment'),('11c091c2','@craft/web/assets/updateswidget/dist'),('11e46241','@app/web/assets/plugins/dist'),('1280018f','@app/web/assets/updateswidget/dist'),('133c4fd8','@lib/velocity'),('1342b841','@app/web/assets/plugins/dist'),('135659e2','@app/web/assets/dbbackup/dist'),('145944f8','@craft/web/assets/updates/dist'),('157e6d4d','@lib/velocity'),('17314154','@lib/velocity'),('185fc53b','@craft/web/assets/updates/dist'),('1978ec8e','@lib/velocity'),('199267ff','@app/web/assets/utilities/dist'),('1a10e922','@craft/web/assets/updates/dist'),('1ad3bf4f','@app/web/assets/sites/dist'),('1bdf17bf','@lib/element-resize-detector'),('1be8e5e5','@app/web/assets/utilities/dist'),('1c12ad4e','@app/web/assets/craftsupport/dist'),('1c425888','@craft/web/assets/deprecationerrors/dist'),('1cb17cad','@app/web/assets/dbbackup/dist'),('1d186d93','@bower/jquery/dist'),('1d28d639','@lib/element-resize-detector'),('1e20e346','@lib/fabric'),('1fda6f13','@lib/fileupload'),('208ba84b','@lib/fabric'),('20eceb43','@craft/web/assets/cp/dist'),('210c1e84','@bower/jquery/dist'),('218e9a6d','@craft/web/assets/dashboard/dist'),('220728d4','@lib/xregexp'),('2241fa96','@lib/jquery.payment'),('22656747','@wbrowar/adminbar/assetbundles/adminbar/dist'),('2265e18b','@app/web/assets/deprecationerrors/dist'),('230645c6','@lib/jquery-ui'),('23378ab1','@lib/velocity'),('23c1b674','@craft/web/assets/dashboard/dist'),('23f9f38e','@app/web/assets/dashboard/dist'),('24b72470','@lib/xregexp'),('25c04b37','@lib/velocity'),('2611fe70','@lib/xregexp'),('26b995f3','@craft/web/assets/updater/dist'),('26c3ce0a','@lib/selectize'),('2767b006','@lib/element-resize-detector'),('286b6c5e','@lib/selectize'),('29192a75','@app/web/assets/utilities/dist'),('292e1ddc','@lib/element-resize-detector'),('2a529fb3','@craft/web/assets/cp/dist'),('2b3b8a5','@bower/jquery/dist'),('2b6131c5','@lib/element-resize-detector'),('2c1ed6c1','@app/web/assets/dashboard/dist'),('2c3a43e1','@app/web/assets/recententries/dist'),('2c7dbafa','@lib/selectize'),('2caf8a80','@lib/xregexp'),('2d231350','@lib/element-resize-detector'),('2d553b0','@app/web/assets/updater/dist'),('2d82c4c4','@app/web/assets/deprecationerrors/dist'),('2d881bae','@craft/web/assets/dashboard/dist'),('2d90b095','@craft/web/assets/installer/dist'),('2e960151','@lib/fileupload'),('2edb60fa','@lib/selectize'),('2f26ed0','@app/web/assets/feed/dist'),('2f28fc95','@app/web/assets/feed/dist'),('2f6c8d04','@lib/fabric'),('2f7ad3ac','@craft/web/assets/recententries/dist'),('2fe9a203','@bower/jquery/dist'),('3177646c','@app/web/assets/cp/dist'),('31da3c6d','@lib/jquery-touch-events'),('3242f8c2','@craft/web/assets/matrixsettings/dist'),('3279235a','@app/web/assets/feed/dist'),('327d8f20','@lib/selectize'),('3288c666','@lib/element-resize-detector'),('32b87dcc','@bower/jquery/dist'),('33e319b0','@app/web/assets/updates/dist'),('3448f5ba','@app/web/assets/utilities/dist'),('344fbc4a','@bower/jquery/dist'),('35497112','@app/web/assets/login/dist'),('35cd7c75','@lib/garnishjs'),('367e00af','@lib/picturefill'),('37483898','@lib/selectize'),('3811cbaa','@lib/xregexp'),('38db20fe','@lib/d3'),('39e7e4df','@lib/jquery.payment'),('3a2a593a','@lib/garnishjs'),('3a9232d2','@craft/web/assets/updateswidget/dist'),('3c043cff','@app/web/assets/updates/dist'),('3d247c12','@lib/xregexp'),('3e66557e','@lib/velocity'),('3e9477d1','@lib'),('3edd30a8','@craft/web/assets/utilities/dist'),('3f102559','@lib/jquery.payment'),('40eb939d','@craft/web/assets/recententries/dist'),('41074160','@lib/fileupload'),('410d760d','@lib/garnishjs'),('423e014b','@lib/jquery-ui'),('42870bc','@craft/web/assets/recententries/dist'),('44330d3','@app/web/assets/utilities/dist'),('447359f6','@lib/velocity'),('451ba0a9','@lib/garnishjs'),('4587d463','@app/web/assets/cp/dist'),('47bd7aa9','@lib/garnishjs'),('481aad30','@app/web/assets/dashboard/dist'),('48245e1','@app/web/assets/installer/dist'),('484b12b2','@app/web/assets/updater/dist'),('486c2fd2','@app/web/assets/feed/dist'),('48c43687','@app/web/assets/updates/dist'),('4928d5c2','@craft/web/assets/updater/dist'),('4b6268e4','@app/web/assets/cp/dist'),('4b68f6f5','@lib/fabric'),('4b7e90a6','@app/web/assets/recententries/dist'),('4cd2e023','@app/web/assets/updates/dist'),('4d2f1a88','@app/web/assets/dashboard/dist'),('4e1c04e3','@app/web/assets/installer/dist'),('4e5d414d','@lib/fabric'),('4e743a23','@app/web/assets/updates/dist'),('4f19a30','@bower/jquery/dist'),('4f5c7d9a','@app/web/assets/login/dist'),('4fa5d459','@lib/garnishjs'),('5015e757','@app/web/assets/deprecationerrors/dist'),('505d7497','@lib/fabric'),('514c7099','@craft/web/assets/utilities/dist'),('5189f552','@app/web/assets/dashboard/dist'),('520da255','@app/web/assets/login/dist'),('52d2d5f9','@app/web/assets/updates/dist'),('52fbae97','@lib/fabric'),('530c26fd','@app/web/assets/utilities/dist'),('532f2f52','@app/web/assets/dashboard/dist'),('534c4369','@lib/selectize'),('53b082eb','@lib/element-resize-detector'),('53cd53cf','@app/web/assets/installer/dist'),('544ba233','@lib/fabric'),('54cb3d65','@craft/web/assets/feed/dist'),('55f4366','@lib/jquery.payment'),('55fcae8b','@bower/jquery/dist'),('562f4f69','@app/web/assets/recententries/dist'),('5633b72b','@app/web/assets/cp/dist'),('568cec4c','@app/web/assets/craftsupport/dist'),('56c722ac','@lib/xregexp'),('574a60cf','@lib/d3'),('57d1772b','@lib/jquery-ui'),('57e76241','@app/web/assets/updates/dist'),('581e408d','@app/web/assets/updateswidget/dist'),('5854f61e','@lib/jquery.payment'),('58cdbca6','@craft/web/assets/feed/dist'),('58d47cde','@craft/web/assets/clearcaches/dist'),('592007e3','@lib/xregexp'),('5998daf1','@lib/jquery-ui'),('59ef409e','@lib/picturefill'),('5a8290bf','@craft/web/assets/feed/dist'),('5ae30067','@lib/fabric'),('5b1b9573','@lib/garnishjs'),('5bd7f6e8','@lib/jquery-ui'),('5cab6626','@lib/selectize'),('5d95d47d','@lib/jquery-ui'),('5e2e22cb','@lib/garnishjs'),('5e4b7c5c','@lib/jquery-touch-events'),('5e96b55d','@wbrowar/adminbar/assetbundles/adminbar/dist'),('608e7615','@craft/web/assets/updates/dist'),('60eb9680','@lib/fileupload'),('61a79e66','@lib/jquery-touch-events'),('62002d2b','@lib/selectize'),('6246d9e','@app/web/assets/generalsettings/dist'),('624d4c80','@lib/fileupload'),('6336151c','@lib/picturefill'),('63d8b7ec','@craft/web/assets/login/dist'),('642f0862','@craft/web/assets/cp/dist'),('649229de','@lib/jquery-touch-events'),('64f77749','@lib/garnishjs'),('64fd4024','@lib/fileupload'),('659180f7','@app/web/assets/updater/dist'),('6597adfb','@craft/web/assets/craftsupport/dist'),('6603a2a4','@lib/picturefill'),('6607a1c6','@app/web/assets/craftsupport/dist'),('66387242','@app/web/assets/cp/dist'),('66a402e3','@app/web/assets/recententries/dist'),('6706bf3','@lib/d3'),('67d881e2','@craft/web/assets/craftsupport/dist'),('686c69a1','@lib/xregexp'),('68950d07','@app/web/assets/updateswidget/dist'),('68a682f5','@lib/d3'),('695353b4','@craft/web/assets/installer/dist'),('6a55e270','@lib/fileupload'),('6b69d092','@lib/jquery-ui'),('6bde0021','@craft/web/assets/craftsupport/dist'),('6beb629','@bower/jquery/dist'),('6c21385','@craft/web/assets/installer/dist'),('6c67a071','@app/web/assets/dbbackup/dist'),('6d54381f','@craft/web/assets/pluginstore/dist'),('6d911a36','@craft/web/assets/login/dist'),('6d93354d','@lib/d3'),('6d9e1114','@lib/jquery-ui'),('6dafde63','@lib/velocity'),('6ec17a71','@app/web/assets/dbbackup/dist'),('6f008af7','@craft/web/assets/dbbackup/dist'),('6fde362f','@craft/web/assets/login/dist'),('70a0a779','@craft/web/assets/utilities/dist'),('70cfcedb','@lib/jquery-ui'),('7188718b','@lib/jquery.payment'),('71b1a377','@lib/fabric'),('72b0618b','@lib/d3'),('72bde38e','@lib/picturefill'),('7326eed','@lib/picturefill'),('74006d2f','@lib/d3'),('7519df4c','@lib/jquery-touch-events'),('752b7bb8','@app/web/assets/searchindexes/dist'),('7554213','@craft/web/assets/updater/dist'),('75c4d2c8','@app/web/assets/updateswidget/dist'),('76a6b72f','@lib/d3'),('7803977e','@lib/picturefill'),('78c05f38','@app/web/assets/updater/dist'),('7909f6','@lib/element-resize-detector'),('7993a774','@app/web/assets/cp/dist'),('7a1ed389','@craft/web/assets/utilities/dist'),('7a6c057e','@lib/element-resize-detector'),('7aa54d7e','@lib/picturefill'),('7b567e09','@app/web/assets/craftsupport/dist'),('7bb17d18','@lib/jquery-touch-events'),('7bde14e2','@lib/fileupload'),('7be9256e','@app/web/assets/cp/dist'),('7c1541da','@lib/picturefill'),('7c18c3df','@lib/d3'),('7c20291e','@bower/jquery/dist'),('7d0171bc','@lib/jquery-touch-events'),('7e51d1f3','@craft/web/assets/updateswidget/dist'),('7e974969','@app/web/assets/installer/dist'),('7eeba35a','@lib/fileupload'),('7fa7abbc','@lib/jquery-touch-events'),('7fd2990','@lib/xregexp'),('7fd73010','@app/web/assets/login/dist'),('80bca473','@lib/d3'),('80f896b0','@craft/web/assets/utilities/dist'),('828fff53','@app/web/assets/utilities/dist'),('82b7baa9','@craft/web/assets/utilities/dist'),('82fefdd0','@lib'),('830a769c','@lib/garnishjs'),('83f91bb6','@lib/jquery-touch-events'),('845d2774','@lib/picturefill'),('847f7725','@bower/jquery/dist'),('84b1aaff','@lib/d3'),('84d4bf05','@craft/web/assets/tablesettings/dist'),('85d6661b','@app/web/assets/dbbackup/dist'),('85fdb71a','@lib/garnishjs'),('86300aff','@lib/jquery.payment'),('86fe86e6','@lib/d3'),('8744fb02','@lib/xregexp'),('885ba6b7','@lib/picturefill'),('886f26a8','@app/web/assets/dashboard/dist'),('895a50ea','@lib/fileupload'),('89795a8f','@craft/web/assets/feed/dist'),('89bcf635','@app/web/assets/pluginstore/dist'),('89bdb8e0','@lib/jquery-touch-events'),('89d72fb0','@lib/jquery.payment'),('8a148aae','@lib/picturefill'),('8a1c41ba','@app/web/assets/login/dist'),('8a6310c1','@lib/jquery-ui'),('8ac33616','@app/web/assets/updates/dist'),('8af80725','@lib/d3'),('8b17e37c','@app/web/assets/cp/dist'),('8b1d7d6d','@lib/fabric'),('8b98526a','@bower/jquery/dist'),('8cfe1773','@craft/web/assets/utilities/dist'),('8d28bf88','@lib/selectize'),('8d54ba2','@lib/picturefill'),('8d68da1c','@app/web/assets/utilities/dist'),('8d6f4693','@app/web/assets/recententries/dist'),('8db0b66c','@lib/jquery-touch-events'),('8e198422','@lib/picturefill'),('8f29f602','@app/web/assets/login/dist'),('8f71bf3','@bower/jquery/dist'),('8fc99c93','@app/web/assets/recententries/dist'),('8fdcc0f4','@craft/web/assets/updater/dist'),('8fff9a75','@lib/jquery-touch-events'),('9022611e','@app/web/assets/cp/dist'),('90b3a749','@lib/fileupload'),('90bb6324','@lib/fabric'),('91b25114','@lib/picturefill'),('9284bb1e','@app/web/assets/cp/dist'),('92fc8b50','@lib/fileupload'),('936f7349','@app/web/assets/recententries/dist'),('941c7460','@app/web/assets/login/dist'),('9434b7ba','@app/web/assets/cp/dist'),('95387316','@craft/web/assets/login/dist'),('953ef967','@app/web/assets/dashboard/dist'),('954497dd','@lib/element-resize-detector'),('959c2a5','@lib/jquery.payment'),('95f08058','@lib/velocity'),('9608d333','@app/web/assets/feed/dist'),('96166dd6','@lib/jquery-touch-events'),('964ca2a2','@lib/fabric'),('96522f','@lib/jquery-touch-events'),('965ac4f1','@app/web/assets/recententries/dist'),('96baae60','@app/web/assets/login/dist'),('96f185dc','@lib/fileupload'),('9792e9d9','@app/web/assets/updates/dist'),('97a9e3d7','@craft/web/assets/dbbackup/dist'),('9974ebc','@lib/d3'),('99eff67c','@app/web/assets/feed/dist'),('9a17a517','@lib/velocity'),('9cb5268a','@lib/fileupload'),('9d3ec4db','@craft/web/assets/craftsupport/dist'),('9e5ba953','@lib/garnishjs'),('9f177145','@lib/d3'),('9fab3c75','@craft/web/assets/dashboard/dist'),('a005455e','@lib/fabric'),('a00d8133','@lib/fileupload'),('a1268cc2','@app/web/assets/updater/dist'),('a131b3d1','@lib/jquery-ui'),('a22bf99f','@craft/web/assets/feed/dist'),('a24a6947','@lib/fabric'),('a2db1d54','@craft/web/assets/cp/dist'),('a3439e84','@lib/picturefill'),('a3479de6','@app/web/assets/craftsupport/dist'),('a408f99f','@lib/element-resize-detector'),('a4e7a246','@lib/jquery-touch-events'),('a4f4381d','@lib/selectize'),('a5632649','@app/web/assets/updates/dist'),('a5d74093','@app/web/assets/installer/dist'),('a64767cb','@lib/fabric'),('a6722a5e','@app/web/assets/craftsupport/dist'),('a67a6323','@craft/web/assets/updates/dist'),('a6fa40b5','@lib/fileupload'),('a719a453','@app/web/assets/updates/dist'),('a7719a93','@app/web/assets/installer/dist'),('a7968066','@app/web/assets/updater/dist'),('a8e0869f','@app/web/assets/updateswidget/dist'),('a9291d21','@lib/jquery-ui'),('aa767644','@app/web/assets/dbbackup/dist'),('ab5bcb55','@lib/velocity'),('ab8fc721','@lib/jquery-ui'),('abefdcd0','@lib/element-resize-detector'),('ac03c49d','@lib/fabric'),('acaa66c3','@lib/garnishjs'),('acc60d70','@craft/web/assets/fields/dist'),('adac253','@lib/jquery-ui'),('add53127','@app/web/assets/updateswidget/dist'),('ade6bed5','@lib/d3'),('ae987c97','@lib/xregexp'),('af991185','@lib/jquery-ui'),('afa74682','@craft/web/assets/installer/dist'),('b0b7611a','@lib/d3'),('b0ba4543','@lib/jquery-ui'),('b16eebc','@lib/jquery.payment'),('b173defd','@app/web/assets/updateswidget/dist'),('b301b3f5','@lib/garnishjs'),('b3b29392','@lib'),('b3d504fd','@app/web/assets/updateswidget/dist'),('b5317690','@craft/web/assets/plugins/dist'),('b5439160','@lib/garnishjs'),('b58ff2fb','@lib/jquery-ui'),('b640a09c','@lib/d3'),('b663778','@lib/garnishjs'),('b66c67cb','@craft/web/assets/craftsupport/dist'),('b70cbd79','@lib/garnishjs'),('b77c64bd','@lib/jquery.payment'),('b8b5d4a0','@app/web/assets/updater/dist'),('b8e46b22','@app/web/assets/dashboard/dist'),('b8e580cd','@lib/picturefill'),('b94510a3','@lib/garnishjs'),('b9b67d89','@lib/jquery-touch-events'),('b9ecb2fd','@lib/fabric'),('bac8f37f','@app/web/assets/updates/dist'),('bad43c28','@bower/jquery/dist'),('bb02fb3d','@app/web/assets/deprecationerrors/dist'),('bbab9f7a','@lib/fileupload'),('bbd77549','@app/web/assets/installer/dist'),('bbe4853','@craft/web/assets/cp/dist'),('bcfb40c7','@craft/web/assets/dbbackup/dist'),('bd47a83c','@app/web/assets/craftsupport/dist'),('bd806318','@app/web/assets/updater/dist'),('be12414b','@lib/picturefill'),('be6ad006','@craft/web/assets/login/dist'),('bee2c2f1','@app/web/assets/installer/dist'),('bf41bc0f','@lib/jquery-touch-events'),('bfe1723c','@app/web/assets/craftsupport/dist'),('c00c826e','@lib/element-resize-detector'),('c07477eb','@craft/web/assets/updateswidget/dist'),('c1be93f2','@lib/fileupload'),('c23b5bf2','@craft/web/assets/updateswidget/dist'),('c27651af','@app/web/assets/craftsupport/dist'),('c303d821','@app/web/assets/updateswidget/dist'),('c4b743ae','@app/web/assets/sites/dist'),('c4ca8b64','@lib/velocity'),('c5cc7c90','@lib/selectize'),('c979aee','@lib/velocity'),('c9eb2312','@craft/web/assets/updates/dist'),('cb140fa9','@craft/web/assets/generalsettings/dist'),('cc72f628','@craft/web/assets/updateswidget/dist'),('cce4fd6e','@app/web/assets/updateswidget/dist'),('cd32a503','@app/web/assets/dbbackup/dist'),('cd9174e0','@app/web/assets/craftsupport/dist'),('cd92224e','@lib/garnishjs'),('ce25b001','@lib'),('ceb527ac','@wbrowar/adminbar/assetbundles/adminbar/dist'),('cfa0381a','@lib/xregexp'),('d00bed2c','@lib/xregexp'),('d0230af0','@lib/selectize'),('d18774fc','@lib/element-resize-detector'),('d3568a1e','@app/web/assets/updater/dist'),('d36a00f6','@craft/web/assets/dbbackup/dist'),('d406e3a0','@lib/xregexp'),('d4be3eb2','@lib/jquery-ui'),('d5019c4f','@app/web/assets/installer/dist'),('d539d9b5','@craft/web/assets/installer/dist'),('d5457c19','@bower/jquery/dist'),('d60c2fb9','@craft/web/assets/cp/dist'),('d649cfb9','@lib/xregexp'),('d776f5ac','@craft/web/assets/installer/dist'),('d7f3b25d','@lib/d3'),('d840917f','@app/web/assets/generalsettings/dist'),('d8458263','@craft/web/assets/cp/dist'),('d8d4f670','@lib/fabric'),('d8ed248c','@lib/jquery.payment'),('d916d1a','@lib/selectize'),('d956920c','@lib/picturefill'),('d99fda0c','@lib/element-resize-detector'),('d9fd27fa','@craft/web/assets/craftsupport/dist'),('da0aae7a','@craft/web/assets/cp/dist'),('da4f4e7a','@lib/xregexp'),('da67a9a6','@lib/selectize'),('dae6b900','@app/web/assets/installer/dist'),('db39000c','@lib/element-resize-detector'),('db591bfd','@lib/jquery-ui'),('db68df54','@craft/web/assets/dashboard/dist'),('db70746f','@craft/web/assets/installer/dist'),('dc258b33','@lib/selectize'),('dcb1af51','@app/web/assets/updater/dist'),('de6aa72a','@lib/selectize'),('deb36e3','@craft/web/assets/updater/dist'),('def2aece','@lib/jquery-touch-events'),('df2fd6a8','@lib/element-resize-detector'),('e0002845','@lib/xregexp'),('e0f4bdc2','@app/web/assets/cp/dist'),('e1308a20','@lib/velocity'),('e234710e','@lib/jquery.payment'),('e2b98002','@craft/web/assets/updates/dist'),('e44ea5db','@lib/garnishjs'),('e4caa8bc','@app/web/assets/login/dist'),('e5265c84','@lib/velocity'),('e5b0160f','@lib/timepicker'),('e5f250f0','@lib/jquery-ui'),('e6e81abe','@craft/web/assets/feed/dist'),('e6f7e9c3','@lib/xregexp'),('e701c6b6','@lib/jquery.payment'),('e7808684','@lib/velocity'),('e807f4f2','@craft/web/assets/updates/dist'),('e8621467','@lib/fileupload'),('e90e0886','@app/web/assets/clearcaches/dist'),('e9392aa0','@app/web/assets/feed/dist'),('e96ca1ed','@app/web/assets/utilities/dist'),('e9cb571','@lib/element-resize-detector'),('ea6c6ccf','@lib/selectize'),('eb2d8df3','@app/web/assets/login/dist'),('eb9ff0a0','@app/web/assets/feed/dist'),('ec591655','@app/web/assets/utilities/dist'),('ec9bad49','@lib/selectize'),('ed87e551','@app/web/assets/updates/dist'),('ef13988d','@app/web/assets/cp/dist'),('ef982874','@lib/velocity'),('ef9c299b','@bower/jquery/dist'),('f03a7c44','@craft/web/assets/dashboard/dist'),('f08a1599','@lib/picturefill'),('f0bf7d5d','@bower/jquery/dist'),('f0fff98f','@app/web/assets/utilities/dist'),('f10871e5','@lib/fabric'),('f1be030','@lib/jquery.payment'),('f20ca8c2','@app/web/assets/feed/dist'),('f259238f','@app/web/assets/utilities/dist'),('f25ebf00','@app/web/assets/recententries/dist'),('f27a2a20','@app/web/assets/dashboard/dist'),('f2c8b446','@craft/web/assets/recententries/dist'),('f3bf879c','@lib/jquery.payment'),('f4a9abf9','@bower/jquery/dist'),('f60f71f9','@bower/jquery/dist'),('f64ff52b','@app/web/assets/utilities/dist'),('f70d73da','@craft/web/assets/updater/dist'),('f717760','@lib/jquery-touch-events'),('f72e295b','@lib/jquery-touch-events'),('f7391f7a','@app/web/assets/feed/dist'),('f73db300','@lib/selectize'),('f829259e','@craft/web/assets/utilities/dist'),('f901f36c','@lib/jquery.payment'),('fad5d7ec','@lib/element-resize-detector'),('fb0bf219','@craft/web/assets/updater/dist'),('fb26695e','@lib/velocity'),('fba7296c','@lib/jquery.payment'),('fc81199c','@craft/web/assets/recententries/dist'),('fd1725c8','@lib/jquery.payment'),('fd51f78a','@lib/xregexp'),('fdb99a4f','@app/web/assets/recententries/dist'),('fe13dee6','@lib/velocity'),('fe17df09','@bower/jquery/dist'),('fe2f35c8','@lib/d3'),('fece3585','@craft/web/assets/recententries/dist');
/*!40000 ALTER TABLE `craft_resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_revisions`
--

LOCK TABLES `craft_revisions` WRITE;
/*!40000 ALTER TABLE `craft_revisions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_searchindex`
--

LOCK TABLES `craft_searchindex` WRITE;
/*!40000 ALTER TABLE `craft_searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `craft_searchindex` VALUES (1,'username',0,1,' ideabase '),(1,'firstname',0,1,''),(1,'lastname',0,1,''),(1,'fullname',0,1,''),(1,'email',0,1,' info ideabasekent com '),(1,'slug',0,1,'');
/*!40000 ALTER TABLE `craft_searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_sections`
--

LOCK TABLES `craft_sections` WRITE;
/*!40000 ALTER TABLE `craft_sections` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_sections_sites`
--

LOCK TABLES `craft_sections_sites` WRITE;
/*!40000 ALTER TABLE `craft_sections_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_sequences`
--

LOCK TABLES `craft_sequences` WRITE;
/*!40000 ALTER TABLE `craft_sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_shunnedmessages`
--

LOCK TABLES `craft_shunnedmessages` WRITE;
/*!40000 ALTER TABLE `craft_shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_sitegroups`
--

LOCK TABLES `craft_sitegroups` WRITE;
/*!40000 ALTER TABLE `craft_sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `craft_sitegroups` VALUES (1,'IdeaBase Starter Kit','2018-09-10 18:44:19','2018-09-10 18:44:19',NULL,'91ccd827-4c84-49fb-84c8-e2d3b2a7c7d1');
/*!40000 ALTER TABLE `craft_sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_sites`
--

LOCK TABLES `craft_sites` WRITE;
/*!40000 ALTER TABLE `craft_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `craft_sites` VALUES (1,1,1,'IdeaBase Starter Kit','default','en-US',1,'@web/',1,'2018-09-10 18:44:19','2018-09-10 18:44:19',NULL,'37224b75-40a6-4c0e-9b6b-3136edacdf9f');
/*!40000 ALTER TABLE `craft_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_structureelements`
--

LOCK TABLES `craft_structureelements` WRITE;
/*!40000 ALTER TABLE `craft_structureelements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_structures`
--

LOCK TABLES `craft_structures` WRITE;
/*!40000 ALTER TABLE `craft_structures` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_systemmessages`
--

LOCK TABLES `craft_systemmessages` WRITE;
/*!40000 ALTER TABLE `craft_systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_taggroups`
--

LOCK TABLES `craft_taggroups` WRITE;
/*!40000 ALTER TABLE `craft_taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_tags`
--

LOCK TABLES `craft_tags` WRITE;
/*!40000 ALTER TABLE `craft_tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_tokens`
--

LOCK TABLES `craft_tokens` WRITE;
/*!40000 ALTER TABLE `craft_tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_usergroups`
--

LOCK TABLES `craft_usergroups` WRITE;
/*!40000 ALTER TABLE `craft_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_usergroups_users`
--

LOCK TABLES `craft_usergroups_users` WRITE;
/*!40000 ALTER TABLE `craft_usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_userpermissions`
--

LOCK TABLES `craft_userpermissions` WRITE;
/*!40000 ALTER TABLE `craft_userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_userpermissions_usergroups`
--

LOCK TABLES `craft_userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `craft_userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_userpermissions_users`
--

LOCK TABLES `craft_userpermissions_users` WRITE;
/*!40000 ALTER TABLE `craft_userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_userpreferences`
--

LOCK TABLES `craft_userpreferences` WRITE;
/*!40000 ALTER TABLE `craft_userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `craft_userpreferences` VALUES (1,'{\"language\":\"en-US\"}');
/*!40000 ALTER TABLE `craft_userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_users`
--

LOCK TABLES `craft_users` WRITE;
/*!40000 ALTER TABLE `craft_users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `craft_users` VALUES (1,'ideabase',NULL,NULL,NULL,'info@ideabasekent.com','$2y$13$SeMYd5qLLgb8qcuvp.ZgAe8/FBgIUWCrBR.up1L2U3ofY1l4jgClS',1,0,0,0,'2019-08-09 18:37:06','::1',NULL,NULL,'2019-08-09 14:41:18',NULL,1,NULL,NULL,NULL,0,'2018-09-10 18:44:21','2018-09-10 18:44:21','2019-08-09 18:37:06','0286b756-17ce-4aa9-99a8-351dc96f37e2');
/*!40000 ALTER TABLE `craft_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_volumefolders`
--

LOCK TABLES `craft_volumefolders` WRITE;
/*!40000 ALTER TABLE `craft_volumefolders` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_volumes`
--

LOCK TABLES `craft_volumes` WRITE;
/*!40000 ALTER TABLE `craft_volumes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craft_volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craft_widgets`
--

LOCK TABLES `craft_widgets` WRITE;
/*!40000 ALTER TABLE `craft_widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `craft_widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,0,'{\"section\":\"*\",\"siteId\":\"1\",\"limit\":10}',1,'2018-09-10 18:44:23','2018-09-10 18:44:23','cc18a216-e634-4739-90c7-fb2a76ce78a0'),(2,1,'craft\\widgets\\CraftSupport',2,0,'[]',1,'2018-09-10 18:44:23','2018-09-10 18:44:23','828799b1-b5f5-4b67-a650-3fd6c71af59e'),(3,1,'craft\\widgets\\Updates',3,0,'[]',1,'2018-09-10 18:44:23','2018-09-10 18:44:23','ecab0272-dab6-41bc-9b40-e0baf3c7cd7e'),(4,1,'craft\\widgets\\Feed',4,0,'{\"url\":\"https://craftcms.com/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2018-09-10 18:44:23','2018-09-10 18:44:23','e4a01b94-a955-4723-848d-332a08303298');
/*!40000 ALTER TABLE `craft_widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'starterkit'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-09 14:38:28
